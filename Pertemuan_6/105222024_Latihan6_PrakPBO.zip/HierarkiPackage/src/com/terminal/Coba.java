package com.terminal;

public class Coba {
    public static void log(String message) {
        Terminal.log(message);
    }
}
