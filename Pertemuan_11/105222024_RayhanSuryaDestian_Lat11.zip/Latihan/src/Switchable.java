public interface Switchable {
    void turnOn();
    void turnOff();
}
