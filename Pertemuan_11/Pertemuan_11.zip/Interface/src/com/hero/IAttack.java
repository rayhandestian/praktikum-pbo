package com.hero;

public interface IAttack {
    public void atttack(Hero enemy);
}
