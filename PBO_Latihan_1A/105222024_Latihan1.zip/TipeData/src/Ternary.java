public class Ternary {
    public static void main(String[] args) {
        var nilai = 75;

        String ucapan = nilai >= 75 ? "Ente lulus" : "Coba lagi ye";

        System.out.println(ucapan);
    }
}
