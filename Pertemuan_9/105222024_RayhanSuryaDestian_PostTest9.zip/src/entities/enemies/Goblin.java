package entities.enemies;

import entities.Enemy;

public class Goblin extends Enemy {
    public Goblin() {
        super("goblin", "Goblin", 40, 10, 6);
    }
}