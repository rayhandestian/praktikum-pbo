package entities.enemies;

import entities.Enemy;

public class Beholder extends Enemy {
    public Beholder() {
        super("beholder", "Beholder", 150, 20, 12);
    }
}