package entities.enemies;

import entities.Enemy;

public class ComicallyLargeSlime extends Enemy{
    public ComicallyLargeSlime() {
        super("comically_large_slime", "Comically Large Slime", 100, 24, 8);
    }
}
