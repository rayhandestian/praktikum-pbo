package entities.enemies;

import entities.Enemy;

public class SmallSlime extends Enemy{
    public SmallSlime() {
        super("small_slime", "Small Slime", 25, 6, 2);
    }
}
