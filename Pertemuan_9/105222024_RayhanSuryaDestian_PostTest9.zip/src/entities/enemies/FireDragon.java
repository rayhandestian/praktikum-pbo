package entities.enemies;

import entities.Enemy;

public class FireDragon extends Enemy {
    public FireDragon() {
        super("fire_dragon", "Fire Dragon", 500, 40, 32);
    }
}